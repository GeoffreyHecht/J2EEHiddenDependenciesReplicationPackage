package test.employe;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.RemoveException;
import javax.naming.InitialContext;
import javax.naming.NamingException;



public class CopyOfMain {
	public static void main(String[] args) throws NumberFormatException, CreateException, RemoveException {
    
		try {
			InitialContext ic = new InitialContext();
			//ModelService mdl = (ModelService) ic.lookup("java:global/TestPoolingEJB/TestPool1");
	

        // Having a lookup for the jndi name specified in 
        // the glassfish-ejb-jar.xml file
        //Object obj = ic.lookup("jndi/TestPooling");	
		Object ejbHome = ic.lookup("jndi/TestPool1");

		
        // Converting Corba object to portable object below
        // and getting the Home interface reference
        EmployeeHome beanhome = 
                (EmployeeHome) javax.rmi.PortableRemoteObject.narrow(ejbHome, EmployeeHome.class); 
        // Calling the create method of home interface which 
        // will return back the reference of remote interface
        Employee  bean = (Employee)beanhome.create(1,"a",Float.valueOf("2.0"));

        // calling the business method of remote interface
        bean.getSalary();
        bean.getEmpName();
        bean.getHandle();
        bean.remove();
        beanhome.remove();
    }
		catch (RemoteException e) {

        e.printStackTrace();
    }
    catch (NamingException e) {

        e.printStackTrace();
    }

	}

	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public CopyOfMain() {
		super();
	}

}
