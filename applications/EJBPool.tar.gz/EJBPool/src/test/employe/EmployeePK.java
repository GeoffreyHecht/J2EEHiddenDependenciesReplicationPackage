package test.employe;

public class EmployeePK {

	public EmployeePK(Integer empNo) {
		// TODO Auto-generated constructor stub
	}

}
