package test.inheritance;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

public interface AbstractTestRemote extends EJBObject {
	public void launchTest() throws RemoteException;
	public void aMethodNotImplementedinBean() throws RemoteException;

}
