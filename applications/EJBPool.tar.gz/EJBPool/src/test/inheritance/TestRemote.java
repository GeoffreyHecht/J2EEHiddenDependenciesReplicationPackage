package test.inheritance;

import java.rmi.RemoteException;

public interface TestRemote extends AbstractTestRemote{
	public void launchTest2() throws RemoteException;
	
}
