package test.inheritance;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionContext;

/**
 * Session Bean implementation class TestPool1
 */
public class TestSession extends AbstractTestSession {

	 public void launchTest() throws RemoteException, CreateException {
	        System.out.println("Hello World by EJB 2.x ...");
	    }
	 
	 public void launchTest2() throws RemoteException, CreateException {
	        System.out.println("Hello World by EJB 2.x ...");
	    }
	 
	 public void launchTest3() throws RemoteException, CreateException {
	        System.out.println("Hello World by EJB 2.x ...");
	    }
}
