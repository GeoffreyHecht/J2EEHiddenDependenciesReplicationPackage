package test.inheritance;

public interface TestHome extends AbstractTestHome{

}
