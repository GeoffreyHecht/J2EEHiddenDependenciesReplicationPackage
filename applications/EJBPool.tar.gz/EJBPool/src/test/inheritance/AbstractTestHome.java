package test.inheritance;

import java.rmi.RemoteException;

import javax.ejb.EJBHome;

public interface AbstractTestHome extends EJBHome {
	public TestRemote create() throws RemoteException;
	public void remove() throws RemoteException;


}
