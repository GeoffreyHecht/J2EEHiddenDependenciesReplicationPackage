package test.pool;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionContext;

/**
 * Session Bean implementation class TestPool1
 */
public class TestPool1 implements javax.ejb.SessionBean {

	public void ejbCreate( ) {
		System.out.println("Create Object of TestPool1");
	}
	
	public void ejbPostCreate( ) {
		System.out.println("PostCreation Object of TestPool1");
	}

	@Override
	public void ejbActivate() throws EJBException, RemoteException {
		// TODO Auto-generated method stub
		System.out.println("Activate Object of TestPool1");
	}

	@Override
	public void ejbPassivate() throws EJBException, RemoteException {
		// TODO Auto-generated method stub
		System.out.println("Passivate Object of TestPool1");
	}

	@Override
	public void ejbRemove() throws EJBException, RemoteException {
		// TODO Auto-generated method stub
		System.out.println("Remove Object of TestPool1");
	}

	@Override
	public void setSessionContext(SessionContext arg0) throws EJBException, RemoteException {
		// TODO Auto-generated method stub
		System.out.println("SetSessionContext Object of TestPool1");
		
	}
	
	 public void launchTest() throws RemoteException, CreateException {
	        System.out.println("Hello World by EJB 2.x ...");
	    }
}
