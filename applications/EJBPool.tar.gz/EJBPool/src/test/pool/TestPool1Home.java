package test.pool;

import java.rmi.RemoteException;

import javax.ejb.EJBHome;

public interface TestPool1Home extends EJBHome {
	public TestPool1Remote create() throws RemoteException;
	public void remove() throws RemoteException;

}
