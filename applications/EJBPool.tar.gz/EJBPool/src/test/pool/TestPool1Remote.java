package test.pool;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

public interface TestPool1Remote extends EJBObject {
	public void launchTest() throws RemoteException;

}
