package test.pool;

import java.rmi.RemoteException;
import java.util.Properties;

import javax.ejb.RemoveException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import test.pool.TestPool1;
import test.pool.TestPool1Home;
import test.pool.TestPool1Remote;


public class Main {
	public static void main(String[] args) throws RemoveException {
    
		try {
			InitialContext ic = new InitialContext();
			//ModelService mdl = (ModelService) ic.lookup("java:global/TestPoolingEJB/TestPool1");
	

        // Having a lookup for the jndi name specified in 
        // the glassfish-ejb-jar.xml file
        //Object obj = ic.lookup("jndi/TestPooling");	
		Object ejbHome = ic.lookup("jndi/TestPool1");

		
        // Converting Corba object to portable object below
        // and getting the Home interface reference
        TestPool1Home beanhome = 
                (TestPool1Home ) javax.rmi.PortableRemoteObject.narrow(ejbHome, TestPool1Home.class); 
        // Calling the create method of home interface which 
        // will return back the reference of remote interface
        TestPool1Remote  bean = (TestPool1Remote)beanhome.create();

        // calling the business method of remote interface
        bean.launchTest();
        bean.remove();
        beanhome.remove();
    }
		catch (RemoteException e) {

        e.printStackTrace();
    }
    catch (NamingException e) {

        e.printStackTrace();
    }

	}

	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public Main() {
		super();
	}

}
