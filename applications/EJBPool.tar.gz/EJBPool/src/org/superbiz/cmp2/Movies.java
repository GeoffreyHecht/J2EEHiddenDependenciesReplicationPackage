package org.superbiz.cmp2;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.util.Collection;

/**
 * @version $Revision$ $Date$
 * from : https://tomee.apache.org/examples-trunk/simple-cmp2/README.html
 */
interface Movies extends javax.ejb.EJBLocalHome {
    Movie create(String director, String title, int year) throws CreateException;

    Movie findByPrimaryKey(Integer primarykey) throws FinderException;

    Collection<Movie> findAll() throws FinderException;

    Collection<Movie> findByDirector(String director) throws FinderException;
}