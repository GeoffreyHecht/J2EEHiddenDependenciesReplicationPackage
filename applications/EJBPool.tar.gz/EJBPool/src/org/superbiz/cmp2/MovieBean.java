package org.superbiz.cmp2;

import javax.ejb.EntityBean;

/**
 * from : https://tomee.apache.org/examples-trunk/simple-cmp2/README.html
 *
 */
public abstract class MovieBean implements EntityBean {

    public MovieBean() {
    }

    public Integer ejbCreate(String director, String title, int year) {
        this.setDirector(director);
        this.setTitle(title);
        this.setYear(year);
        return null;
    }

    public abstract java.lang.Integer getId();

    public abstract void setId(java.lang.Integer id);

    public abstract String getDirector();

    public abstract void setDirector(String director);

    public abstract String getTitle();

    public abstract void setTitle(String title);

    public abstract int getYear();

    public abstract void setYear(int year);

}