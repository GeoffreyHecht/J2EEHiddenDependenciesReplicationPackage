package org.superbiz.cmp2;

import java.rmi.RemoteException;
import java.util.Properties;

import javax.ejb.CreateException;
import javax.ejb.RemoveException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import test.pool.TestPool1Home;



public class CopyOfMain {
	public static void main(String[] args) throws NumberFormatException, CreateException {
    
		try {
			InitialContext ic = new InitialContext();
			//ModelService mdl = (ModelService) ic.lookup("java:global/TestPoolingEJB/TestPool1");
	

        // Having a lookup for the jndi name specified in 
        // the glassfish-ejb-jar.xml file
        //Object obj = ic.lookup("jndi/TestPooling");	
		Object ejbHome = ic.lookup("jndi/TestPool1");

		
        // Converting Corba object to portable object below
        // and getting the Home interface reference
        Movies beanhome = 
                (Movies) javax.rmi.PortableRemoteObject.narrow(ejbHome, TestPool1Home.class); 
        // Calling the create method of home interface which 
        // will return back the reference of remote interface
          Movie  bean= (Movie)beanhome.create("aa", "aaa", 1898);

        // calling the business method of remote interface
        bean.getTitle();
        bean.getYear();
    }
		catch (NamingException e) {

        e.printStackTrace();
    }

	}

	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public CopyOfMain() {
		super();
	}

}
