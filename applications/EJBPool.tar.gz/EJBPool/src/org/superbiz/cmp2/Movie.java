package org.superbiz.cmp2;

/**
 * @version $Revision$ $Date$
 * from : https://tomee.apache.org/examples-trunk/simple-cmp2/README.html
 */
public interface Movie extends javax.ejb.EJBLocalObject {
    java.lang.Integer getId();

    void setId(java.lang.Integer id);

    String getDirector();

    void setDirector(String director);

    String getTitle();

    void setTitle(String title);

    int getYear();

    void setYear(int year);
}
